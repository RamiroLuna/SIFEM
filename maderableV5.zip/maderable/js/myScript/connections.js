StringUrl = 'http://187.188.96.133:8080/ServiceBosque/';

var urlServiceOficial = {
    url: StringUrl + 'ConsultasOficialia',
    type: 'POST',
    dataType: 'json'
};

var urlServiceReforestacion = {
    url: StringUrl+'Reforestacion',
    type: 'POST',
    dataType: 'json'
};

var urlServiceReforestemos = {
    url: StringUrl + 'ConsultaReforestemos',
    type: 'POST',
    dataType: 'json'
};



var urlService = {
    url: StringUrl + 'Reforestacion',
    type: 'POST',
    dataType: 'json'
};

var urlServiceQR = {
	url: StringUrl + 'QR',
    type: 'GET',
    dataType : 'binary'
 };

var urlServiceCoordinador = {
    url: StringUrl + 'Coordinador',
    type: 'POST',
    dataType: 'json'
};


var urlServiceAbogado = {
    url: StringUrl + 'Abogado',
    type: 'POST',
    dataType: 'json'
};



